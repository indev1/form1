package trahman;

import trahman.Lst;

public interface List {
	public Lst list = new Lst();
}
